<?php

namespace Razorpay\IFSC\Exception;

class InvalidCode extends \RuntimeException
{

}
